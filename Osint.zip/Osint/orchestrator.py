"""
orchestrator.py - Runs OSINT tools as subprocesses, parses and normalizes results
"""

import asyncio
import subprocess
import json
import re
import socket
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
import aiohttp
import dns.resolver
import whois
import logging

logger = logging.getLogger("orchestrator")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)


# ─────────────────────────────────────────────
# UTILITY
# ─────────────────────────────────────────────

async def run_cmd(cmd: list, timeout: int = 120) -> tuple[str, str, int]:
    """Run a shell command asynchronously and return stdout, stderr, returncode."""
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return stdout.decode(errors="ignore"), stderr.decode(errors="ignore"), proc.returncode
    except asyncio.TimeoutError:
        logger.warning(f"Command timed out: {' '.join(cmd)}")
        return "", "Timeout", -1
    except FileNotFoundError:
        logger.warning(f"Tool not found: {cmd[0]}")
        return "", f"Tool not found: {cmd[0]}", -1


def is_ip(target: str) -> bool:
    try:
        socket.inet_aton(target)
        return True
    except:
        return False


# ─────────────────────────────────────────────
# MODULE 1: DNS RECON
# ─────────────────────────────────────────────

async def run_dns_recon(target: str) -> dict:
    logger.info(f"[DNS] Starting DNS recon for {target}")
    results = {
        "a_records": [], "mx_records": [], "ns_records": [],
        "txt_records": [], "cname_records": [], "errors": []
    }
    resolver = dns.resolver.Resolver()
    resolver.timeout = 5

    for rtype in ["A", "MX", "NS", "TXT", "CNAME"]:
        try:
            answers = resolver.resolve(target, rtype)
            key = f"{rtype.lower()}_records"
            for r in answers:
                results[key].append(str(r))
        except Exception as e:
            results["errors"].append(f"{rtype}: {str(e)}")

    logger.info(f"[DNS] Done: {len(results['a_records'])} A records found")
    return results


# ─────────────────────────────────────────────
# MODULE 2: WHOIS
# ─────────────────────────────────────────────

async def run_whois(target: str) -> dict:
    logger.info(f"[WHOIS] Looking up {target}")
    try:
        loop = asyncio.get_event_loop()
        w = await loop.run_in_executor(None, whois.whois, target)
        return {
            "registrar": str(w.registrar or ""),
            "creation_date": str(w.creation_date or ""),
            "expiration_date": str(w.expiration_date or ""),
            "name_servers": w.name_servers or [],
            "emails": w.emails or [],
            "org": str(w.org or ""),
            "country": str(w.country or ""),
        }
    except Exception as e:
        logger.warning(f"[WHOIS] Failed: {e}")
        return {"error": str(e)}


# ─────────────────────────────────────────────
# MODULE 3: SUBFINDER (subdomain enumeration)
# ─────────────────────────────────────────────

async def run_subfinder(domain: str) -> dict:
    logger.info(f"[Subfinder] Enumerating subdomains for {domain}")
    stdout, stderr, code = await run_cmd(
        ["subfinder", "-d", domain, "-silent", "-o", "/dev/stdout"],
        timeout=120
    )
    subdomains = [s.strip() for s in stdout.splitlines() if s.strip()]
    logger.info(f"[Subfinder] Found {len(subdomains)} subdomains")
    return {"subdomains": subdomains, "count": len(subdomains)}


# ─────────────────────────────────────────────
# MODULE 4: CERTIFICATE TRANSPARENCY (crt.sh)
# ─────────────────────────────────────────────

async def run_crtsh(domain: str) -> dict:
    logger.info(f"[crt.sh] Querying certificate transparency for {domain}")
    url = f"https://crt.sh/?q=%.{domain}&output=json"
    domains = set()
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                if resp.status == 200:
                    data = await resp.json(content_type=None)
                    for entry in data:
                        name = entry.get("name_value", "")
                        for d in name.split("\n"):
                            d = d.strip().lstrip("*.")
                            if d and domain in d:
                                domains.add(d)
    except Exception as e:
        logger.warning(f"[crt.sh] Failed: {e}")
        return {"crt_domains": [], "error": str(e)}

    result = sorted(domains)
    logger.info(f"[crt.sh] Found {len(result)} cert domains")
    return {"crt_domains": result}


# ─────────────────────────────────────────────
# MODULE 5: NMAP PORT SCAN
# ─────────────────────────────────────────────

async def run_nmap(target: str) -> dict:
    logger.info(f"[Nmap] Scanning {target}")
    stdout, stderr, code = await run_cmd(
        ["nmap", "-sV", "-sC", "--open", "-T4", "-oX", "-", target],
        timeout=180
    )
    ports = []
    if stdout and code == 0:
        try:
            root = ET.fromstring(stdout)
            for host in root.findall("host"):
                for port in host.findall(".//port"):
                    state = port.find("state")
                    service = port.find("service")
                    if state is not None and state.get("state") == "open":
                        ports.append({
                            "port": int(port.get("portid")),
                            "protocol": port.get("protocol"),
                            "service": service.get("name") if service is not None else "unknown",
                            "version": (service.get("product", "") + " " + service.get("version", "")).strip() if service is not None else "",
                            "extra": service.get("extrainfo", "") if service is not None else ""
                        })
        except ET.ParseError as e:
            logger.warning(f"[Nmap] XML parse error: {e}")

    logger.info(f"[Nmap] Found {len(ports)} open ports")
    return {"ports": ports, "count": len(ports)}


# ─────────────────────────────────────────────
# MODULE 6: WHATWEB (tech fingerprinting)
# ─────────────────────────────────────────────

async def run_whatweb(target: str) -> dict:
    logger.info(f"[WhatWeb] Fingerprinting {target}")
    url = target if target.startswith("http") else f"http://{target}"
    stdout, stderr, code = await run_cmd(
        ["whatweb", "--log-json=/dev/stdout", url],
        timeout=60
    )
    technologies = []
    try:
        lines = [l for l in stdout.splitlines() if l.strip().startswith("[")]
        if lines:
            data = json.loads(lines[0])
            if isinstance(data, list):
                for entry in data:
                    for tech, details in entry.get("plugins", {}).items():
                        technologies.append({
                            "name": tech,
                            "version": details.get("version", [""])[0] if details.get("version") else ""
                        })
    except Exception as e:
        logger.warning(f"[WhatWeb] Parse error: {e}")

    logger.info(f"[WhatWeb] Detected {len(technologies)} technologies")
    return {"technologies": technologies}


# ─────────────────────────────────────────────
# MODULE 7: theHarvester (emails/hosts)
# ─────────────────────────────────────────────

async def run_harvester(domain: str) -> dict:
    logger.info(f"[theHarvester] Harvesting {domain}")
    out_file = DATA_DIR / f"harvester_{domain.replace('.','_')}.json"
    stdout, stderr, code = await run_cmd(
        ["python3", "/opt/theHarvester/theHarvester.py",
         "-d", domain, "-b", "anubis,certspotter,crtsh,dnsdumpster,hackertarget",
         "-f", str(out_file)],
        timeout=120
    )
    emails, hosts = [], []
    json_path = Path(str(out_file) + ".json")
    if json_path.exists():
        try:
            data = json.loads(json_path.read_text())
            emails = data.get("emails", [])
            hosts = data.get("hosts", [])
        except:
            pass
    # fallback: parse stdout
    if not emails and not hosts:
        for line in stdout.splitlines():
            if "@" in line and "." in line:
                emails.append(line.strip())
            elif re.match(r"[\w\-\.]+\." + re.escape(domain), line.strip()):
                hosts.append(line.strip())

    logger.info(f"[theHarvester] Found {len(emails)} emails, {len(hosts)} hosts")
    return {"emails": list(set(emails)), "hosts": list(set(hosts))}


# ─────────────────────────────────────────────
# MODULE 8: NUCLEI VULNERABILITY SCAN
# ─────────────────────────────────────────────

async def run_nuclei(target: str) -> dict:
    logger.info(f"[Nuclei] Scanning {target}")
    url = target if target.startswith("http") else f"http://{target}"
    stdout, stderr, code = await run_cmd(
        ["nuclei", "-u", url, "-severity", "critical,high,medium",
         "-json", "-silent", "-no-color"],
        timeout=300
    )
    vulns = []
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            data = json.loads(line)
            vulns.append({
                "template_id": data.get("template-id", ""),
                "name": data.get("info", {}).get("name", ""),
                "severity": data.get("info", {}).get("severity", "unknown"),
                "description": data.get("info", {}).get("description", ""),
                "matched_url": data.get("matched-at", ""),
                "tags": data.get("info", {}).get("tags", []),
                "reference": data.get("info", {}).get("reference", []),
            })
        except json.JSONDecodeError:
            continue

    logger.info(f"[Nuclei] Found {len(vulns)} vulnerabilities")
    return {"vulnerabilities": vulns, "count": len(vulns)}


# ─────────────────────────────────────────────
# MODULE 9: CVE LOOKUP (NVD API - free, no key)
# ─────────────────────────────────────────────

async def lookup_cves_for_services(ports: list) -> list:
    """For each service+version found by nmap, query NVD for CVEs."""
    logger.info(f"[CVE] Looking up CVEs for {len(ports)} services")
    all_cves = []
    async with aiohttp.ClientSession() as session:
        for port in ports:
            service = port.get("service", "")
            version = port.get("version", "")
            if not service or service in ["tcpwrapped", "unknown"]:
                continue

            query = f"{service} {version}".strip()
            url = f"https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch={query}&resultsPerPage=5"
            try:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        for item in data.get("vulnerabilities", []):
                            cve = item.get("cve", {})
                            metrics = cve.get("metrics", {})
                            cvss_score = 0.0
                            severity = "UNKNOWN"

                            # Try CVSSv3 first, then v2
                            for key in ["cvssMetricV31", "cvssMetricV30", "cvssMetricV2"]:
                                m = metrics.get(key, [])
                                if m:
                                    cvss_data = m[0].get("cvssData", {})
                                    cvss_score = cvss_data.get("baseScore", 0.0)
                                    severity = cvss_data.get("baseSeverity", "UNKNOWN")
                                    break

                            desc = ""
                            for d in cve.get("descriptions", []):
                                if d.get("lang") == "en":
                                    desc = d.get("value", "")
                                    break

                            all_cves.append({
                                "cve_id": cve.get("id", ""),
                                "service": service,
                                "port": port.get("port"),
                                "cvss_score": cvss_score,
                                "severity": severity,
                                "description": desc[:300],
                                "published": cve.get("published", ""),
                            })
                await asyncio.sleep(0.6)  # NVD rate limit: ~10 req/min without key
            except Exception as e:
                logger.warning(f"[CVE] Failed for {query}: {e}")

    all_cves.sort(key=lambda x: x["cvss_score"], reverse=True)
    logger.info(f"[CVE] Total CVEs found: {len(all_cves)}")
    return all_cves


# ─────────────────────────────────────────────
# MODULE 10: RISK SCORER
# ─────────────────────────────────────────────

def calculate_risk(scan_results: dict) -> dict:
    score = 0
    factors = []

    # CVE severity
    cves = scan_results.get("cves", [])
    critical_cves = [c for c in cves if c.get("severity") in ["CRITICAL", "HIGH"]]
    if critical_cves:
        score += min(40, len(critical_cves) * 10)
        factors.append(f"{len(critical_cves)} Critical/High CVEs found")

    # Nuclei vulns
    nuclei_vulns = scan_results.get("nuclei", {}).get("vulnerabilities", [])
    crit_nuclei = [v for v in nuclei_vulns if v.get("severity") in ["critical", "high"]]
    if crit_nuclei:
        score += min(30, len(crit_nuclei) * 10)
        factors.append(f"{len(crit_nuclei)} Critical/High template matches")

    # Exposed ports
    ports = scan_results.get("nmap", {}).get("ports", [])
    risky_ports = [p for p in ports if p.get("port") in [21, 22, 23, 25, 3389, 5900, 6379, 27017, 9200]]
    if risky_ports:
        score += len(risky_ports) * 5
        factors.append(f"{len(risky_ports)} risky ports exposed ({', '.join(str(p['port']) for p in risky_ports)})")

    # Email breach would go here (HIBP API optional)

    # Clamp 0-100
    score = min(100, score)

    if score >= 75:
        level = "CRITICAL"
        color = "#ff2d55"
    elif score >= 50:
        level = "HIGH"
        color = "#ff6b35"
    elif score >= 25:
        level = "MEDIUM"
        color = "#ffd60a"
    else:
        level = "LOW"
        color = "#30d158"

    return {
        "score": score,
        "level": level,
        "color": color,
        "factors": factors
    }


# ─────────────────────────────────────────────
# MAIN SCAN ORCHESTRATOR
# ─────────────────────────────────────────────

async def run_full_scan(target: str, scan_id: str, progress_callback=None) -> dict:
    """
    Run all modules concurrently where possible, return unified results.
    progress_callback(step: str, pct: int) for live updates.
    """

    def update(step, pct):
        if progress_callback:
            progress_callback(step, pct)
        logger.info(f"[Scan {scan_id}] {step} ({pct}%)")

    domain = target if not is_ip(target) else target
    update("Starting scan", 5)

    # Phase 1: Passive recon (run concurrently)
    update("Running passive recon (DNS, WHOIS, crt.sh, Subfinder, Harvester)", 10)
    passive_tasks = await asyncio.gather(
        run_dns_recon(domain),
        run_whois(domain),
        run_crtsh(domain) if not is_ip(target) else asyncio.sleep(0, result={}),
        run_subfinder(domain) if not is_ip(target) else asyncio.sleep(0, result={}),
        run_harvester(domain) if not is_ip(target) else asyncio.sleep(0, result={}),
        return_exceptions=True
    )
    dns_data, whois_data, crt_data, subfinder_data, harvester_data = [
        r if not isinstance(r, Exception) else {} for r in passive_tasks
    ]
    update("Passive recon complete", 35)

    # Phase 2: Active recon (sequential, heavier)
    update("Running port scan (Nmap)", 40)
    nmap_data = await run_nmap(target)
    update("Nmap complete", 55)

    update("Fingerprinting technologies (WhatWeb)", 58)
    whatweb_data = await run_whatweb(target)
    update("WhatWeb complete", 65)

    # Phase 3: Vulnerability scanning
    update("Running vulnerability scan (Nuclei)", 68)
    nuclei_data = await run_nuclei(target)
    update("Nuclei complete", 80)

    update("Looking up CVEs for detected services", 82)
    cves = await lookup_cves_for_services(nmap_data.get("ports", []))
    update("CVE lookup complete", 92)

    # Phase 4: Combine & score
    update("Calculating risk score", 95)

    # Deduplicate subdomains from all sources
    all_subdomains = list(set(
        subfinder_data.get("subdomains", []) +
        crt_data.get("crt_domains", []) +
        harvester_data.get("hosts", [])
    ))

    results = {
        "scan_id": scan_id,
        "target": target,
        "timestamp": datetime.utcnow().isoformat(),
        "dns": dns_data,
        "whois": whois_data,
        "subdomains": all_subdomains,
        "emails": harvester_data.get("emails", []),
        "nmap": nmap_data,
        "whatweb": whatweb_data,
        "nuclei": nuclei_data,
        "cves": cves,
    }

    results["risk"] = calculate_risk(results)
    update("Scan complete", 100)

    return results
