# Unified OSINT & Vulnerability System

A self-hosted recon + vulnerability intelligence platform for Rocky Linux.

## Stack
- **Backend**: Python 3 + FastAPI + SQLite
- **Frontend**: Vanilla JS dashboard (dark terminal UI)
- **Tools**: theHarvester · Subfinder · Nmap · Nuclei · WhatWeb · Amass
- **APIs**: NVD/NIST (free, no key) · crt.sh (free, no key)

---

## Installation (Rocky Linux)

```bash
# 1. Clone or copy files to your machine
git clone <your-repo> /opt/osint-system
cd /opt/osint-system

# 2. Run installer as root
sudo bash install.sh

# 3. Start the system
cd /opt/osint-system
python3 backend.py

# 4. Open browser
http://localhost:8080
```

---

## Project Structure

```
osint-system/
├── install.sh          # Rocky Linux installer (tools + deps)
├── backend.py          # FastAPI server (API + DB)
├── orchestrator.py     # Scan engine (runs tools, parses output)
├── requirements.txt    # Python dependencies
├── static/
│   └── index.html      # Dashboard UI
└── data/               # SQLite DB + scan artifacts (auto-created)
```

---

## What Each Module Does

| Module | Tool | Output |
|--------|------|--------|
| DNS Recon | dnspython | A/MX/NS/TXT/CNAME records |
| WHOIS | python-whois | Registrar, dates, emails, org |
| Subdomain Enum | Subfinder | All subdomains (50+ sources) |
| Cert Transparency | crt.sh HTTP | Subdomains from SSL certs |
| Email Harvest | theHarvester | Emails, hosts from OSINT sources |
| Port Scan | Nmap | Open ports, services, versions |
| Tech Fingerprint | WhatWeb | CMS, frameworks, server info |
| Vuln Scan | Nuclei | 9000+ vulnerability templates |
| CVE Lookup | NVD API | CVEs matched to detected services |
| Risk Scoring | Custom | 0-100 score with breakdown |

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/scan` | Start a new scan `{"target":"domain.com"}` |
| GET | `/api/scan/{id}/status` | Poll scan progress |
| GET | `/api/scan/{id}/results` | Get full results JSON |
| GET | `/api/scans` | List all scans |
| DELETE | `/api/scan/{id}` | Delete a scan |
| GET | `/api/scan/{id}/report` | Download JSON report |

---

## Manual Tool Installation Check

```bash
which nmap subfinder nuclei whatweb amass
python3 -c "import theHarvester" 2>/dev/null && echo "theHarvester OK"
```

---

## Systemd (Run as Service)

```bash
sudo systemctl enable osint-system
sudo systemctl start osint-system
sudo systemctl status osint-system
```

---

## Adding API Keys (Optional - Improves Results)

Edit `orchestrator.py` and add keys to the relevant sections:

- **Shodan**: Add `SHODAN_API_KEY` env variable for internet-exposed asset data
- **Hunter.io**: Add to theHarvester `api-keys.yaml` for more email results
- **SecurityTrails**: Add to Subfinder config for more subdomains

---

## ⚠️ Legal

Only scan targets you own or have explicit written authorization to test.
This tool is for authorized security assessments and research only.
