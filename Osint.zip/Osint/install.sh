#!/bin/bash
# ============================================================
# UNIFIED OSINT & VULNERABILITY SYSTEM - Rocky Linux Installer
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log()    { echo -e "${GREEN}[+]${NC} $1"; }
warn()   { echo -e "${YELLOW}[!]${NC} $1"; }
error()  { echo -e "${RED}[-]${NC} $1"; exit 1; }
header() { echo -e "\n${CYAN}========== $1 ==========${NC}"; }

check_root() {
    if [ "$EUID" -ne 0 ]; then
        error "Please run as root: sudo bash install.sh"
    fi
}

header "System Update & Base Dependencies"
check_root

dnf update -y
dnf install -y epel-release
dnf install -y \
    python3 python3-pip python3-devel \
    nmap \
    git curl wget unzip tar \
    gcc gcc-c++ make \
    ruby ruby-devel \
    golang \
    sqlite \
    chromium \
    jq

log "Base packages installed."

header "Python Dependencies"
pip3 install --upgrade pip
pip3 install \
    fastapi \
    uvicorn[standard] \
    aiofiles \
    python-multipart \
    requests \
    aiohttp \
    dnspython \
    python-whois \
    beautifulsoup4 \
    lxml \
    colorama \
    tqdm \
    sqlalchemy \
    pydantic \
    jinja2 \
    weasyprint

log "Python packages installed."

header "Installing theHarvester"
cd /opt
if [ ! -d "theHarvester" ]; then
    git clone https://github.com/laramies/theHarvester.git
fi
cd theHarvester
pip3 install -r requirements/base.txt
ln -sf /opt/theHarvester/theHarvester.py /usr/local/bin/theHarvester
chmod +x /opt/theHarvester/theHarvester.py
log "theHarvester installed."

header "Installing Subfinder"
cd /tmp
SUBFINDER_VER=$(curl -s https://api.github.com/repos/projectdiscovery/subfinder/releases/latest | jq -r .tag_name)
wget -q "https://github.com/projectdiscovery/subfinder/releases/latest/download/subfinder_${SUBFINDER_VER#v}_linux_amd64.zip" -O subfinder.zip
unzip -o subfinder.zip subfinder -d /usr/local/bin/
chmod +x /usr/local/bin/subfinder
log "Subfinder installed."

header "Installing Nuclei"
cd /tmp
NUCLEI_VER=$(curl -s https://api.github.com/repos/projectdiscovery/nuclei/releases/latest | jq -r .tag_name)
wget -q "https://github.com/projectdiscovery/nuclei/releases/latest/download/nuclei_${NUCLEI_VER#v}_linux_amd64.zip" -O nuclei.zip
unzip -o nuclei.zip nuclei -d /usr/local/bin/
chmod +x /usr/local/bin/nuclei
log "Nuclei installed. Updating templates..."
nuclei -update-templates -silent
log "Nuclei templates updated."

header "Installing WhatWeb"
gem install whatweb 2>/dev/null || warn "WhatWeb install failed, skipping."
log "WhatWeb installed."

header "Installing Amass"
cd /tmp
AMASS_VER=$(curl -s https://api.github.com/repos/owasp-amass/amass/releases/latest | jq -r .tag_name)
wget -q "https://github.com/owasp-amass/amass/releases/latest/download/amass_linux_amd64.zip" -O amass.zip
unzip -o amass.zip -d amass_dir
cp amass_dir/amass_linux_amd64/amass /usr/local/bin/
chmod +x /usr/local/bin/amass
log "Amass installed."

header "Firewall"
if command -v firewall-cmd &>/dev/null; then
    firewall-cmd --permanent --add-port=8080/tcp
    firewall-cmd --reload
    log "Port 8080 opened."
fi

header "Setting Up Data Directory"
mkdir -p /opt/osint-system/data /opt/osint-system/reports
cp -r /home/$(logname 2>/dev/null || echo "root")/osint-system/* /opt/osint-system/ 2>/dev/null || true

header "Creating systemd Service"
cat > /etc/systemd/system/osint-system.service << 'EOF'
[Unit]
Description=Unified OSINT & Vulnerability System
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/osint-system
ExecStart=/usr/bin/python3 /opt/osint-system/backend.py
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
log "Systemd service created. Start with: systemctl start osint-system"

header "Installation Complete!"
echo -e "${GREEN}"
echo "  ██████╗ ███████╗██╗███╗   ██╗████████╗"
echo "  ██╔══██╗██╔════╝██║████╗  ██║╚══██╔══╝"
echo "  ██║  ██║███████╗██║██╔██╗ ██║   ██║   "
echo "  ██║  ██║╚════██║██║██║╚██╗██║   ██║   "
echo "  ██████╔╝███████║██║██║ ╚████║   ██║   "
echo "  ╚═════╝ ╚══════╝╚═╝╚═╝  ╚═══╝   ╚═╝  "
echo -e "${NC}"
echo -e "  Run: ${CYAN}cd /opt/osint-system && python3 backend.py${NC}"
echo -e "  Open: ${CYAN}http://localhost:8080${NC}"
echo ""
