"""
backend.py - FastAPI server for the Unified OSINT & Vulnerability System
"""

import asyncio
import json
import uuid
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import sqlalchemy as sa
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker, declarative_base

from orchestrator import run_full_scan

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("backend")

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)

DB_PATH = DATA_DIR / "osint.db"
engine = create_async_engine(f"sqlite+aiosqlite:///{DB_PATH}", echo=False)
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
Base = declarative_base()

# ─────────────────────────────────────────────
# DATABASE MODELS
# ─────────────────────────────────────────────

class ScanRecord(Base):
    __tablename__ = "scans"
    id = sa.Column(sa.String, primary_key=True)
    target = sa.Column(sa.String, nullable=False)
    status = sa.Column(sa.String, default="pending")  # pending, running, done, failed
    progress = sa.Column(sa.Integer, default=0)
    step = sa.Column(sa.String, default="Queued")
    results = sa.Column(sa.Text, nullable=True)  # JSON blob
    created_at = sa.Column(sa.DateTime, default=datetime.utcnow)
    completed_at = sa.Column(sa.DateTime, nullable=True)


# ─────────────────────────────────────────────
# APP
# ─────────────────────────────────────────────

app = FastAPI(title="Unified OSINT & Vulnerability System", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static files (dashboard)
static_dir = Path("static")
static_dir.mkdir(exist_ok=True)


@app.on_event("startup")
async def startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database initialized.")


# ─────────────────────────────────────────────
# REQUEST MODELS
# ─────────────────────────────────────────────

class ScanRequest(BaseModel):
    target: str
    note: Optional[str] = ""


# ─────────────────────────────────────────────
# BACKGROUND SCAN WORKER
# ─────────────────────────────────────────────

active_scans = {}  # scan_id -> task

async def run_scan_background(scan_id: str, target: str):
    async with AsyncSessionLocal() as db:
        scan = await db.get(ScanRecord, scan_id)
        scan.status = "running"
        await db.commit()

    def progress_cb(step: str, pct: int):
        asyncio.ensure_future(_update_progress(scan_id, step, pct))

    try:
        results = await run_full_scan(target, scan_id, progress_callback=progress_cb)
        async with AsyncSessionLocal() as db:
            scan = await db.get(ScanRecord, scan_id)
            scan.status = "done"
            scan.progress = 100
            scan.step = "Complete"
            scan.results = json.dumps(results)
            scan.completed_at = datetime.utcnow()
            await db.commit()
        logger.info(f"Scan {scan_id} completed.")
    except Exception as e:
        logger.error(f"Scan {scan_id} failed: {e}", exc_info=True)
        async with AsyncSessionLocal() as db:
            scan = await db.get(ScanRecord, scan_id)
            scan.status = "failed"
            scan.step = f"Error: {str(e)[:200]}"
            await db.commit()


async def _update_progress(scan_id: str, step: str, pct: int):
    try:
        async with AsyncSessionLocal() as db:
            scan = await db.get(ScanRecord, scan_id)
            if scan:
                scan.progress = pct
                scan.step = step
                await db.commit()
    except:
        pass


# ─────────────────────────────────────────────
# API ROUTES
# ─────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def root():
    html_file = Path("static/index.html")
    if html_file.exists():
        return HTMLResponse(html_file.read_text())
    return HTMLResponse("<h1>OSINT System</h1><p>Place index.html in /static/</p>")


@app.post("/api/scan")
async def start_scan(req: ScanRequest, background_tasks: BackgroundTasks):
    target = req.target.strip().lower()
    target = target.replace("https://", "").replace("http://", "").rstrip("/")

    if not target:
        raise HTTPException(status_code=400, detail="Target is required")

    scan_id = str(uuid.uuid4())[:8]

    async with AsyncSessionLocal() as db:
        scan = ScanRecord(id=scan_id, target=target, status="pending", step="Queued")
        db.add(scan)
        await db.commit()

    background_tasks.add_task(run_scan_background, scan_id, target)
    logger.info(f"Scan {scan_id} started for target: {target}")

    return {"scan_id": scan_id, "target": target, "status": "pending"}


@app.get("/api/scan/{scan_id}/status")
async def get_scan_status(scan_id: str):
    async with AsyncSessionLocal() as db:
        scan = await db.get(ScanRecord, scan_id)
        if not scan:
            raise HTTPException(status_code=404, detail="Scan not found")
        return {
            "scan_id": scan.id,
            "target": scan.target,
            "status": scan.status,
            "progress": scan.progress,
            "step": scan.step,
            "created_at": scan.created_at.isoformat() if scan.created_at else None,
        }


@app.get("/api/scan/{scan_id}/results")
async def get_scan_results(scan_id: str):
    async with AsyncSessionLocal() as db:
        scan = await db.get(ScanRecord, scan_id)
        if not scan:
            raise HTTPException(status_code=404, detail="Scan not found")
        if scan.status != "done":
            return JSONResponse({"status": scan.status, "step": scan.step, "progress": scan.progress})
        return JSONResponse(json.loads(scan.results))


@app.get("/api/scans")
async def list_scans():
    async with AsyncSessionLocal() as db:
        result = await db.execute(
            sa.select(ScanRecord).order_by(ScanRecord.created_at.desc()).limit(50)
        )
        scans = result.scalars().all()
        return [
            {
                "scan_id": s.id,
                "target": s.target,
                "status": s.status,
                "progress": s.progress,
                "step": s.step,
                "created_at": s.created_at.isoformat() if s.created_at else None,
                "risk": json.loads(s.results).get("risk") if s.results else None,
            }
            for s in scans
        ]


@app.delete("/api/scan/{scan_id}")
async def delete_scan(scan_id: str):
    async with AsyncSessionLocal() as db:
        scan = await db.get(ScanRecord, scan_id)
        if not scan:
            raise HTTPException(status_code=404, detail="Scan not found")
        await db.delete(scan)
        await db.commit()
    return {"deleted": scan_id}


@app.get("/api/scan/{scan_id}/report")
async def export_report(scan_id: str):
    """Export scan results as a formatted JSON report."""
    async with AsyncSessionLocal() as db:
        scan = await db.get(ScanRecord, scan_id)
        if not scan or scan.status != "done":
            raise HTTPException(status_code=404, detail="Scan not found or not complete")
        results = json.loads(scan.results)

    report_path = DATA_DIR / f"report_{scan_id}.json"
    report_path.write_text(json.dumps(results, indent=2))
    return FileResponse(str(report_path), filename=f"osint_report_{scan.target}_{scan_id}.json")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    import aiosqlite  # ensure it's importable

    print("""
    ╔══════════════════════════════════════════╗
    ║   Unified OSINT & Vulnerability System   ║
    ║   http://localhost:8080                  ║
    ╚══════════════════════════════════════════╝
    """)
    uvicorn.run(app, host="0.0.0.0", port=8080, log_level="info")
